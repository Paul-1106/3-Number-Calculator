#include <iostream>

int main() {

	double number1;
	double number2;
	double number3;
	char o1;
	char o2;
	double subTotal;
	double grandTotal;

	std::cout << "Enter the number: " << std::endl;
	std::cin >> number1;

	std::cout << "Select your first operator: " << std::endl;
	std::cin >> o1;

	std::cout << "Enter the second number: " << std::endl;
	std::cin >> number2;

	std::cout << "Select your second operator: " << std::endl;
	std::cin >> o2;

	std::cout << "Enter your third number: " << std::endl;
	std::cin >> number3;

	if (o1 == '+') {
		subTotal = number1 + number2;
	}
	else if (o1 == '-') {
		subTotal = number1 - number2;
	}
	else if (o1 == '*') {
		subTotal = number1 * number2;
	}
	else if (o1 == '/') {
		subTotal = number1 / number2;
	}
	else {
		std::cout << "Invalid first operator" << std::endl;
		return 0;
	}

	if (o2 == '+') {
		grandTotal = subTotal + number3;
	}
	else if (o2 == '-') {
		grandTotal = subTotal - number3;
	}
	else if (o2 == '*') {
		grandTotal = subTotal * number3;
	}
	else if (o2 == '/') {
		grandTotal = subTotal / number3;
	}
	else {
		std::cout << "Invalid second operator" << std::endl;
		return 0;
	}

	std::cout << "The Total: " << grandTotal << std::endl;

	return 0;
}